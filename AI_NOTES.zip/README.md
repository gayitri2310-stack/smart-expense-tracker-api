# Smart Expense Tracker API

Run:

```bash
uvicorn src.main:app --reload
```
