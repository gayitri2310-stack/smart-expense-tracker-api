from fastapi import FastAPI, HTTPException
from src.models import Expense

app = FastAPI(title="Smart Expense Tracker API")
expenses=[]

@app.get("/")
def home():
    return {"message":"Welcome to Smart Expense Tracker API"}

@app.post("/expenses")
def add_expense(expense: Expense):
    expenses.append(expense)
    return {"message":"Expense added successfully","expense":expense}

@app.get("/expenses")
def get_expenses(category:str=None):
    if category:
        return [e for e in expenses if e.category.lower()==category.lower()]
    return expenses

@app.get("/expenses/total")
def total_expenses():
    return {"total_expense":sum(e.amount for e in expenses)}

@app.get("/expenses/total/{category}")
def total_by_category(category:str):
    return {"category":category,"total":sum(e.amount for e in expenses if e.category.lower()==category.lower())}

@app.delete("/expenses/{expense_id}")
def delete_expense(expense_id:int):
    for e in expenses:
        if e.id==expense_id:
            expenses.remove(e)
            return {"message":"Expense deleted successfully"}
    raise HTTPException(status_code=404, detail="Expense not found")
